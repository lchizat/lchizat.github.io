In order to read the videos:
- Unzip in a single folder
- Open the file main.pdf with Adobe Acrobat Reader
- Click on the images (some are animated, some aren't)